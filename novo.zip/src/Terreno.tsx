// Terreno.tsx
import { useEffect, useState } from 'react';
import * as THREE from 'three';
import { GAME_CONFIG } from './config';

export function Terreno() {
    // Em vez de usar useRef num plano pré-fabricado, geramos a geometria do zero
    const [geometry, setGeometry] = useState<THREE.BufferGeometry | null>(null);

    useEffect(() => {
        fetch('/terreno.raw')
            .then((res) => {
                if (!res.ok) throw new Error("Ficheiro RAW não encontrado.");
                return res.arrayBuffer();
            })
            .then((buffer) => {
                const rawData = new Uint16Array(buffer);
                const tamanhoRaw = Math.floor(Math.sqrt(rawData.length));

                if (tamanhoRaw === 0) return;

                // 1. Lógica exata do Terreno.h para cálculo da grelha
                const passoAmostragem = tamanhoRaw > 256 ? Math.floor(tamanhoRaw / 256) : 1;
                const larguraGrid = Math.floor(tamanhoRaw / passoAmostragem);
                const profundidadeGrid = larguraGrid;

                // 2. Extração dos fatores de escala originais[cite: 5]
                const { espacamento, ondulacao } = GAME_CONFIG.terreno.parametros;
                const espacamentoMetrico = espacamento * 0.005;
                const escalaOndulacao = ondulacao * 0.05;

                // 3. Offsets para centralizar[cite: 5]
                const offsetX = (larguraGrid * espacamentoMetrico) * 0.5;
                const offsetZ = (profundidadeGrid * espacamentoMetrico) * 0.5;

                // Arrays tipados para performance na web
                const positions = new Float32Array(larguraGrid * profundidadeGrid * 3);
                const indices = [];

                // 4. Criação dos Vértices (Posições 3D)[cite: 5]
                for (let z = 0; z < profundidadeGrid; ++z) {
                    for (let x = 0; x < larguraGrid; ++x) {
                        const origX = x * passoAmostragem;
                        const origZ = z * passoAmostragem;

                        // Leitura da altitude normalizada de 16 bits[cite: 5]
                        const val = rawData[origZ * tamanhoRaw + origX] || 0;
                        const h = val / 65535.0;

                        const posX = (x * espacamentoMetrico) - offsetX;
                        const posY = h * escalaOndulacao;
                        const posZ = (z * espacamentoMetrico) - offsetZ;

                        const idx = (z * larguraGrid + x) * 3;
                        positions[idx] = posX;
                        positions[idx + 1] = posY;
                        positions[idx + 2] = posZ;
                    }
                }

                // 5. Criação dos Triângulos (Índices)[cite: 5]
                for (let z = 0; z < profundidadeGrid - 1; ++z) {
                    for (let x = 0; x < larguraGrid - 1; ++x) {
                        const i0 = z * larguraGrid + x;
                        const i1 = z * larguraGrid + (x + 1);
                        const i2 = (z + 1) * larguraGrid + x;
                        const i3 = (z + 1) * larguraGrid + (x + 1);

                        indices.push(i0, i2, i1);
                        indices.push(i1, i2, i3);
                    }
                }

                // 6. Construção da BufferGeometry nativa
                const geo = new THREE.BufferGeometry();
                geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
                geo.setIndex(indices);
                geo.computeVertexNormals();
                geo.computeBoundingBox();
                geo.computeBoundingSphere();

                setGeometry(geo);
            })
            .catch((err) => console.error("Erro ao gerar terreno:", err));
    }, []);

    // Enquanto carrega e calcula, não renderizamos nada
    if (!geometry) return null;

    return (
        // Não precisamos de rotation=[-Math.PI / 2, 0, 0] porque os vértices já foram gerados com o Y para cima, igual ao C++
        <mesh geometry={geometry} receiveShadow>
            <meshStandardMaterial color="#3E8E41" roughness={0.9} />
        </mesh>
    );
}