// App.tsx
import React from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei'; // <-- Removido o AxesHelper daqui
import { GAME_CONFIG } from './config';
import { Terreno } from './Terreno';

export default function App() {
  const { luz } = GAME_CONFIG;
  const { dirX, dirY, dirZ, intensidadeAmbiente, intensidadeDifusa } = luz.parametros;

  return (
    <div style={{ width: '100vw', height: '100vh', backgroundColor: '#87CEEB' }}>
      <Canvas shadows camera={{ position: [0, 20, -80], fov: 60, far: 50000 }}>
        <ambientLight intensity={intensidadeAmbiente} />
        <directionalLight
          position={[dirX * 100, dirY * 100, dirZ * 100]}
          intensity={intensidadeDifusa}
          castShadow
          shadow-mapSize={[2048, 2048]}
        />
        <OrbitControls makeDefault />

        {/* Usamos diretamente em minúsculo, o R3F entende nativamente */}
        <axesHelper args={[50]} />

        <Terreno />

      </Canvas>
    </div>
  );
}